<?php
require_once "config.php";

if (!isset($_GET['id'])) {
    die("No club selected.");
}

$club_id = (int)$_GET['id'];

// Load club from USERS table (NOT clubs table)
$stmt = $pdo->prepare("
    SELECT id, name, club_picture, email, created_at 
    FROM users 
    WHERE id = ? AND profession = 'Staff' AND role = 'user'
");
$stmt->execute([$club_id]);

$club = $stmt->fetch();

if (!$club) {
    die("Club not found.");
}
?>
<!DOCTYPE html>
<html>
<head>
<title><?= htmlspecialchars($club['name']); ?></title>
<style>
body {
    background:#f0f8ff;
    font-family:system-ui;
    padding:2rem;
}

.club-card {
    background:white;
    max-width:800px;
    margin:auto;
    padding:2rem;
    border-radius:16px;
    box-shadow:0 4px 20px rgba(0,0,0,0.1);
    text-align:center;
}

.club-card img {
    width:150px;
    height:150px;
    border-radius:50%;
    object-fit:cover;
    border:4px solid #3b82f6;
    margin-bottom:1rem;
}

.club-card h1 {
    font-size:2rem;
    color:#1e40af;
    margin-bottom:0.5rem;
}

.club-card p {
    color:#444;
    font-size:1rem;
    margin-top:0.5rem;
}

.contact-btn {
    display:inline-block;
    margin-top:1.5rem;
    background:#3b82f6;
    color:white;
    padding:12px 20px;
    border-radius:8px;
    text-decoration:none;
    font-weight:600;
    transition:0.2s;
}

.contact-btn:hover {
    background:#2563eb;
}
</style>
</head>
<body>

<div class="club-card">
    <img src="/<?= $club['club_picture'] ?>" alt="Club Picture">

    <h1><?= htmlspecialchars($club['name']) ?></h1>

    <p><strong>Founded:</strong> <?= date("F j, Y", strtotime($club['created_at'])) ?></p>

    <p>This club does not yet have a description page. Add one later!</p>

    <a href="mailto:<?= $club['email'] ?>?subject=Hello%20<?= urlencode($club['name']) ?>"
       class="contact-btn">
        📩 Contact <?= htmlspecialchars($club['name']) ?>
    </a>
</div>

</body>
</html>

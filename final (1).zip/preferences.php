<?php
require_once 'config.php';
if (!isLoggedIn()) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Load old preferences (if exist)
$stmt = $pdo->prepare("SELECT * FROM user_preferences WHERE user_id = ?");
$stmt->execute([$user_id]);
$pref = $stmt->fetch();

$likes = $pref['likes'] ?? "";
$dislikes = $pref['dislikes'] ?? "";
$stylePref = $pref['preferred_event_style'] ?? "";
$timePref = $pref['preferred_time'] ?? "";
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Your Preferences</title>

<style>
    :root { --blue: #3b82f6; --red: #ef4444; --green: #10b981; --gray:#6b7280; }
    * { margin:0; padding:0; box-sizing:border-box; font-family:system-ui,-apple-system,sans-serif; }

    body { background:#f0f8ff; color:#333; min-height:100vh; }

    .header {
        display:flex; justify-content:space-between; align-items:center;
        padding:1rem 2rem; background:rgba(255,255,255,0.9);
        backdrop-filter:blur(10px); border-bottom:1px solid #eee;
        position:sticky; top:0; z-index:100;
    }

    .logo img { height:32px; }

    .user { display:flex; align-items:center; gap:12px; }
    .avatar { width:40px;height:40px;background:var(--blue);color:white;
              border-radius:50%;display:grid;place-items:center;font-weight:600;font-size:1.2rem; }
    .logout { background:var(--red); color:white; border:none;
              padding:8px 16px; border-radius:8px; cursor:pointer; font-weight:500; }

    .container { max-width:900px; margin:2rem auto; padding:0 1rem; }

    .section {
        background:white; border-radius:16px; padding:2rem;
        margin-bottom:2rem; box-shadow:0 4px 20px rgba(0,0,0,0.05);
    }

    h2 { font-size:1.8rem; color:#1e40af; text-align:center; margin-bottom:1.5rem; }

    label { display:block; margin-bottom:0.5rem; font-weight:500; color:var(--gray); }
    input, textarea, select {
        width:100%; padding:0.75rem; border:1px solid #d1d5db; border-radius:8px;
        font-size:1rem;
    }
    input:focus, textarea:focus, select:focus {
        outline:none; border-color:var(--blue); box-shadow:0 0 0 3px rgba(59,130,246,0.2);
    }

    textarea { min-height:100px; resize:vertical; }

    .btn {
        background:var(--blue); color:white; border:none; padding:0.75rem 1.5rem;
        border-radius:8px; cursor:pointer; font-weight:600; transition:0.2s;
        width:100%; margin-top:1rem;
    }
    .btn:hover { background:#2563eb; transform:translateY(-1px); }

    .back-link {
        text-align:center;
        margin-top:1rem;
        font-size:1rem;
    }
    .back-link a {
        color:var(--blue);
        font-weight:600;
        text-decoration:none;
    }
</style>

</head>
<body>

<div class="header">
    <div class="https://eventsync.io/assets/logo-018c7909b72b80b364152f440f79ea8678c8ff237502415f489f821ed15fe284.svg">
    </div>
    <div class="user">
        <div class="avatar"><?php echo strtoupper(substr($_SESSION['user_name'],0,1)); ?></div>
        <div>
            <div><strong><?php echo htmlspecialchars($_SESSION['user_name']); ?></strong></div>
            <div style="font-size:0.85rem;color:var(--gray);"><?php echo ucfirst($_SESSION['profession']); ?></div>
        </div>
        <button class="logout" onclick="location='logout.php'">Logout</button>
    </div>
</div>

<div class="container">

    <div class="section">
        <h2>Your Event Preferences</h2>

        <form method="POST" action="save_preferences.php">

            <label>What do you enjoy?</label>
            <textarea name="likes" placeholder="music, sports, workshops"><?= htmlspecialchars($likes) ?></textarea>

            <label>What do you NOT enjoy?</label>
            <textarea name="dislikes" placeholder="parties, loud events"><?= htmlspecialchars($dislikes) ?></textarea>

            <label>Preferred Event Style</label>
            <select name="preferred_event_style">
                <option value="">Select…</option>
                <option value="calm" <?= $stylePref === "calm" ? "selected" : "" ?>>Calm & educational</option>
                <option value="fun" <?= $stylePref === "fun" ? "selected" : "" ?>>Fun & energetic</option>
                <option value="networking" <?= $stylePref === "networking" ? "selected" : "" ?>>Networking & clubs</option>
            </select>

            <label>Preferred Time of Day</label>
            <select name="preferred_time">
                <option value="">Select…</option>
                <option value="morning" <?= $timePref === "morning" ? "selected" : "" ?>>Morning</option>
                <option value="afternoon" <?= $timePref === "afternoon" ? "selected" : "" ?>>Afternoon</option>
                <option value="evening" <?= $timePref === "evening" ? "selected" : "" ?>>Evening</option>
            </select>

            <button class="btn" type="submit">Save Preferences</button>
        </form>

        <div class="back-link">
            <a href="dashboard.php">← Back to Dashboard</a>
        </div>

    </div>
</div>

</body>
</html>

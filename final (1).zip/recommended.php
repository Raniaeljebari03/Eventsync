<?php
require_once 'config.php';
if (!isLoggedIn()) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Load preferences
$stmt = $pdo->prepare("SELECT * FROM user_preferences WHERE user_id = ?");
$stmt->execute([$user_id]);
$pref = $stmt->fetch();

if (!$pref) {
    die("<h2 style='text-align:center;margin-top:2rem;'>You have no saved preferences yet.</h2>
         <p style='text-align:center;'><a href='preferences.php' style='color:#2563eb;font-weight:600;'>Set Preferences</a></p>");
}

// Load all events
$events = $pdo->query("SELECT * FROM events ORDER BY date_time ASC")->fetchAll();

// Build recommendation scores
$recommendations = [];

foreach ($events as $e) {
    $score = 0;
    $text = strtolower($e['name'] . " " . $e['description']);

    foreach (explode(",", $pref['likes']) as $like) {
        if ($like && strpos($text, strtolower(trim($like))) !== false) {
            $score += 40;
        }
    }

    foreach (explode(",", $pref['dislikes']) as $dis) {
        if ($dis && strpos($text, strtolower(trim($dis))) !== false) {
            $score -= 50;
        }
    }

    $hour = date("H", strtotime($e['date_time']));
    if ($pref['preferred_time'] === "morning" && $hour < 12) $score += 10;
    if ($pref['preferred_time'] === "afternoon" && $hour >= 12 && $hour < 17) $score += 10;
    if ($pref['preferred_time'] === "evening" && $hour >= 17) $score += 10;

    $e['score'] = $score;
    $recommendations[] = $e;
}

usort($recommendations, fn($a,$b)=>$b['score'] - $a['score']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Recommended Events</title>

<style>
    :root { --blue:#3b82f6; --red:#ef4444; --green:#10b981; --gray:#6b7280; }

    * { margin:0; padding:0; box-sizing:border-box; font-family:system-ui,-apple-system,sans-serif; }

    body { background:#f0f8ff; color:#333; min-height:100vh; }

    .header {
        display:flex; justify-content:space-between; align-items:center;
        padding:1rem 2rem; background:rgba(255,255,255,0.9);
        border-bottom:1px solid #eee; backdrop-filter:blur(10px);
        position:sticky; top:0; z-index:100;
    }

    .logo img { height:32px; }

    .user { display:flex; align-items:center; gap:12px; }
    .avatar { 
        width:40px;height:40px;background:var(--blue);color:white;
        border-radius:50%;display:grid;place-items:center;
        font-weight:600;font-size:1.2rem;
    }
    .logout {
        background:var(--red); color:white; border:none; padding:8px 16px;
        border-radius:8px; cursor:pointer; font-weight:500;
    }

    .container { max-width:1200px; margin:2rem auto; padding:0 1rem; }

    h2 {
        font-size:1.8rem;
        color:#1e40af;
        text-align:center;
        margin-bottom:2rem;
    }

    .events {
        display:grid;
        gap:1.5rem;
        grid-template-columns:repeat(auto-fill, minmax(300px, 1fr));
    }

    .card {
        background:white; border-radius:16px; overflow:hidden;
        box-shadow:0 4px 15px rgba(0,0,0,0.08);
        padding:1rem;
        transition:0.3s;
    }
    .card:hover { transform:translateY(-4px); }

    .card-img img {
        width:100%; height:180px; object-fit:cover; border-radius:12px;
    }

    .score {
        background:#e0f2fe;
        color:#0369a1;
        padding:4px 10px;
        border-radius:6px;
        font-weight:600;
        display:inline-block;
        margin-bottom:0.5rem;
    }

    .back-link {
        text-align:center;
        margin-top:2rem;
    }
    .back-link a {
        color:var(--blue);
        font-weight:600;
        text-decoration:none;
    }
</style>

</head>

<body>

<!-- HEADER -->
<div class="header">
    <div class="logo">
        <img src="https://eventsync.io/assets/logo-018c7909b72b80b364152f440f79ea8678c8ff237502415f489f821ed15fe284.svg">
    </div>

    <div class="user">
        <div class="avatar"><?php echo strtoupper(substr($_SESSION['user_name'],0,1)); ?></div>
        <div>
            <div><strong><?php echo htmlspecialchars($_SESSION['user_name']); ?></strong></div>
            <div style="font-size:0.85rem;color:var(--gray);">
                <?php echo ucfirst($_SESSION['profession']); ?>
            </div>
        </div>
        <button class="logout" onclick="location='logout.php'">Logout</button>
    </div>
</div>


<div class="container">

    <h2>Recommended Events for You</h2>

    <div class="events">
        <?php foreach (array_slice($recommendations, 0, 6) as $e): ?>
            <div class="card">

                <?php if ($e['picture']): ?>
                    <div class="card-img">
                        <img src="<?= htmlspecialchars($e['picture']) ?>">
                    </div>
                <?php endif; ?>

                <span class="score">Match Score: <?= $e['score'] ?></span>

                <h3 style="margin-top:0.5rem;"><?= htmlspecialchars($e['name']) ?></h3>
                <p style="color:#555; margin-top:0.25rem;">
                    <?= nl2br(htmlspecialchars($e['description'])) ?>
                </p>

                <p style="margin-top:0.5rem;color:#374151;">
                    <strong>Date:</strong> <?= date("M j, Y g:i A", strtotime($e['date_time'])) ?><br>
                    <strong>Location:</strong> <?= htmlspecialchars($e['place']) ?>
                </p>

            </div>
        <?php endforeach; ?>
    </div>

    <div class="back-link">
        <a href="dashboard.php">← Back to Dashboard</a>
    </div>

</div>

</body>
</html>

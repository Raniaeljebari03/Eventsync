<?php
require_once 'config.php';
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Get numeric user_id from session
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    // Fallback: fetch from caswallet_id
    $stmt = $pdo->prepare("SELECT id FROM users WHERE caswallet_id = ?");
    $stmt->execute([$_SESSION['user']]);
    $row = $stmt->fetch();
    if ($row) {
        $_SESSION['user_id'] = $user_id = $row['id'];
    } else {
        die("Session error. Please log in again.");
    }
}
$profession = $_SESSION['profession'];
$message = '';
$messageType = '';
$stories = $pdo->query("
    SELECT s.*, u.name 
    FROM stories s 
    JOIN users u ON s.user_id = u.id
    WHERE s.expires_at > NOW()
    ORDER BY s.created_at DESC
")->fetchAll();
$clubs = $pdo->query("
    SELECT id, name, club_picture 
    FROM users 
    WHERE profession = 'Staff' AND role = 'user'
    ORDER BY name ASC
")->fetchAll();
if ($profession === 'Staff' && isset($_POST['create_story'])) {

    if (!empty($_FILES['story_image']['name']) && $_FILES['story_image']['error'] == 0) {
        
        $dir = 'uploads/stories/';
        if (!is_dir($dir)) mkdir($dir, 0755, true);

        $ext = pathinfo($_FILES['story_image']['name'], PATHINFO_EXTENSION);
        $file = $dir . uniqid() . '.' . $ext;
        move_uploaded_file($_FILES['story_image']['tmp_name'], $file);

        $caption = trim($_POST['caption']);
        $expires = date("Y-m-d H:i:s", strtotime("+24 hours"));

        $stmt = $pdo->prepare(
            "INSERT INTO stories (user_id, image, caption, expires_at)
             VALUES (?, ?, ?, ?)"
        );
        $stmt->execute([$user_id, $file, $caption, $expires]);

        $message = "Your story has been posted!";
        $messageType = "success";
    }
}

// Create Event (Staff only)
if ($profession === 'Staff' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_event'])) {
    $name = trim($_POST['event_name']);
    $date_time = $_POST['date_time'];
    $place = trim($_POST['place']);
    $places = (int)$_POST['available_places'];
    $desc = trim($_POST['description'] ?? '');

    if (empty($name) || empty($date_time) || empty($place) || $places < 1) {
        $message = "All fields required.";
        $messageType = 'error';
    } else {
        $pic = null;
        if (!empty($_FILES['picture']['name']) && $_FILES['picture']['error'] == 0) {
            $dir = 'uploads/events/';
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            $ext = pathinfo($_FILES['picture']['name'], PATHINFO_EXTENSION);
            $pic = $dir . uniqid() . '.' . $ext;
            move_uploaded_file($_FILES['picture']['tmp_name'], $pic);
        }

        try {
            $stmt = $pdo->prepare("INSERT INTO events (name, picture, date_time, place, available_places, created_by, description) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$name, $pic, $date_time, $place, $places, $user_id, $desc]);
            $message = "Event created!";
            $messageType = 'success';
        } catch (Exception $e) {
            $message = "Error: " . $e->getMessage();
            $messageType = 'error';
        }
    }
}

// Reserve Spot
if (isset($_POST['reserve_event'])) {
    $event_id = (int)$_POST['event_id'];
    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("SELECT available_places FROM events WHERE id = ? FOR UPDATE");
        $stmt->execute([$event_id]);
        $row = $stmt->fetch();
        if ($row && $row['available_places'] > 0) {
            $check = $pdo->prepare("SELECT 1 FROM reservations WHERE event_id = ? AND user_id = ?");
            $check->execute([$event_id, $user_id]);
            if ($check->fetch()) {
                $pdo->rollBack();
                $message = "Already reserved!";
                $messageType = 'error';
            } else {
                $pdo->prepare("INSERT INTO reservations (event_id, user_id) VALUES (?, ?)")->execute([$event_id, $user_id]);
                $pdo->prepare("UPDATE events SET available_places = available_places - 1 WHERE id = ?")->execute([$event_id]);
                $pdo->commit();
                $message = "Reserved!";
                $messageType = 'success';
            }
        } else {
            $pdo->rollBack();
            $message = "No spots left.";
            $messageType = 'error';
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        $message = "Error: " . $e->getMessage();
        $messageType = 'error';
    }
}

// Unreserve Spot
if (isset($_POST['unreserve_event'])) {
    $event_id = (int)$_POST['event_id'];
    try {
        $pdo->beginTransaction();
        $check = $pdo->prepare("SELECT 1 FROM reservations WHERE event_id = ? AND user_id = ?");
        $check->execute([$event_id, $user_id]);
        if ($check->fetch()) {
            $pdo->prepare("DELETE FROM reservations WHERE event_id = ? AND user_id = ?")->execute([$event_id, $user_id]);
            $pdo->prepare("UPDATE events SET available_places = available_places + 1 WHERE id = ?")->execute([$event_id]);
            $pdo->commit();
            $message = "Unreserved! Spot freed up.";
            $messageType = 'success';
        } else {
            $pdo->rollBack();
            $message = "No reservation found.";
            $messageType = 'error';
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        $message = "Error: " . $e->getMessage();
        $messageType = 'error';
    }
}

// Load events
$events = $pdo->query("SELECT e.*, u.name AS creator FROM events e JOIN users u ON e.created_by = u.id ORDER BY date_time ASC")->fetchAll();

// Load my reservations
$res = $pdo->prepare("SELECT event_id FROM reservations WHERE user_id = ?");
$res->execute([$user_id]);
$my_reservations = $res->fetchAll(PDO::FETCH_COLUMN, 0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        :root { --blue: #3b82f6; --red: #ef4444; --green: #10b981; --gray: #6b7280; }
        * { margin:0; padding:0; box-sizing:border-box; font-family:system-ui,-apple-system,sans-serif; }
        body { background:#f0f8ff; color:#333; min-height:100vh; }
        .header { display:flex; justify-content:space-between; align-items:center; padding:1rem 2rem; background:rgba(255,255,255,0.9); backdrop-filter:blur(10px); border-bottom:1px solid #eee; position:sticky; top:0; z-index:100; }
        .logo img { height:32px; }
        .user { display:flex; align-items:center; gap:12px; }
        .avatar { width:40px; height:40px; background:var(--blue); color:white; border-radius:50%; display:grid; place-items:center; font-weight:600; font-size:1.2rem; }
        .logout { background:var(--red); color:white; border:none; padding:8px 16px; border-radius:8px; cursor:pointer; font-weight:500; }
        .container { max-width:1200px; margin:2rem auto; padding:0 1rem; }
        .message { padding:1rem; border-radius:12px; margin-bottom:1.5rem; text-align:center; font-weight:500; }
        .success { background:#dcfce7; color:#166534; border:1px solid #22c55e; }
        .error { background:#fee2e2; color:#991b1b; border:1px solid #ef4444; }
        .section { background:white; border-radius:16px; padding:2rem; margin-bottom:2rem; box-shadow:0 4px 20px rgba(0,0,0,0.05); }
        h2 { font-size:1.8rem; color:#1e40af; margin-bottom:1.5rem; text-align:center; }
        .form-grid { display:grid; gap:1rem; grid-template-columns:repeat(auto-fit, minmax(280px,1fr)); }
        label { display:block; margin-bottom:0.5rem; font-weight:500; color:var(--gray); }
        input, textarea, select { width:100%; padding:0.75rem; border:1px solid #d1d5db; border-radius:8px; font-size:1rem; }
        input:focus, textarea:focus { outline:none; border-color:var(--blue); box-shadow:0 0 0 3px rgba(59,130,246,0.2); }
        textarea { min-height:100px; resize:vertical; }
        .btn { background:var(--blue); color:white; border:none; padding:0.75rem 1.5rem; border-radius:8px; cursor:pointer; font-weight:600; transition:0.2s; }
        .btn:hover { background:#2563eb; transform:translateY(-1px); }
        .events { display:grid; gap:1.5rem; grid-template-columns:repeat(auto-fill, minmax(300px,1fr)); }
        .card { background:white; border-radius:16px; overflow:hidden; box-shadow:0 4px 15px rgba(0,0,0,0.08); transition:0.3s; cursor:pointer; }
        .card:hover { transform:translateY(-6px); box-shadow:0 12px 30px rgba(0,0,0,0.15); }
        .card.full { opacity:0.6; filter:grayscale(80%); pointer-events:none; }
        .card-img { height:180px; background:#e5e7eb; overflow:hidden; }
        .card-img img { width:100%; height:100%; object-fit:cover; }
        .card-body { padding:1.25rem; }
        .card-title { font-size:1.25rem; font-weight:600; margin-bottom:0.5rem; color:#111; }
        .card-meta { font-size:0.9rem; color:var(--gray); margin-bottom:0.75rem; line-height:1.4; }
        .spots { font-weight:600; }
        .spots.full { color:var(--red); }
        .spots.available { color:var(--green); }
        .card-actions { display:flex; gap:0.75rem; margin-top:1rem; }
        .btn-small { flex:1; padding:0.6rem; font-size:0.9rem; text-align:center; border-radius:8px; }
        .btn-reserve { background:var(--blue); color:white; }
        .btn-unreserve { background:var(--red); color:white; }
        .btn-reserved { background:var(--green); cursor:default; }
        .btn-details { background:var(--gray); color:white; }
        .modal { display:none; position:fixed; inset:0; background:rgba(0,0,0,0.6); backdrop-filter:blur(5px); z-index:1000; align-items:center; justify-content:center; padding:1rem; }
        .modal.show { display:flex; }
        .modal-content { background:white; border-radius:20px; max-width:800px; width:90%; max-height:90vh; overflow:auto; position:relative; box-shadow:0 20px 50px rgba(0,0,0,0.2); }
        .modal-header { padding:1.5rem 1.5rem 0; }
        .modal-title { font-size:1.6rem; font-weight:700; color:#1e40af; }
        .modal-close { position:absolute; top:1rem; right:1rem; background:none; border:none; font-size:1.8rem; cursor:pointer; color:var(--gray); }
        .modal-body { padding:1.5rem; }
        .modal-img { width:100%; border-radius:12px; margin-bottom:1rem; }
        .modal p { margin-bottom:0.75rem; line-height:1.5; }
        .modal strong { color:#111; }
        @media (max-width:640px) {
            .header { flex-direction:column; gap:1rem; text-align:center; }
            .form-grid { grid-template-columns:1fr; }
            .card-actions { flex-direction:column; }
        }
    </style>
    <style>
.story-bar {
    display:flex;
    gap:15px;
    overflow-x:auto;
    padding:10px 0;
    margin-bottom:20px;
}

.story-bubble {
    text-align:center;
    cursor:pointer;
}

.story-bubble img {
    width:60px;
    height:60px;
    border-radius:50%;
    object-fit:cover;
    border:3px solid #3b82f6;
}

.story-bubble span {
    font-size:12px;
    color:#333;
    display:block;
    margin-top:5px;
}
</style>

</head>
<body>

<div class="header">
    <div class="logo">
        <img src="https://eventsync.io/assets/logo-018c7909b72b80b364152f440f79ea8678c8ff237502415f489f821ed15fe284.svg" alt="Logo">
    </div>
    <div class="user">
        
        <div class="avatar"><?php echo strtoupper(substr($_SESSION['user_name'],0,1)); ?></div>
        <div>
            <div><strong><?php echo htmlspecialchars($_SESSION['user_name']); ?></strong></div>
            <div style="font-size:0.85rem;color:var(--gray);"><?php echo ucfirst($profession); ?></div>
        </div>
        <div style="text-align:right; margin-bottom:1rem;">
   <?php if ($profession === 'Student' || $profession === 'Teacher'): ?>
   
<a href="preferences.php" class="btn">
    ⚙️ Update Preferences
</a>
<?php endif; ?>

</div>

        <button class="logout" onclick="location='logout.php'">Logout</button>
    </div>
    
</div>


<div class="container">

<div class="club-sidebar">
    
    <?php foreach ($clubs as $c): ?>
        <a href="club.php?id=<?= $c['id'] ?>" class="club-item">
            <img src="<?= $c['club_picture'] ?: 'default_club.png' ?>" alt="">
            <span><?= htmlspecialchars($c['name']) ?></span>
        </a>
    <?php endforeach; ?>
</div>



<style>.club-sidebar {
    position: fixed;
    top: 50%;
    right: 20px;
    transform: translateY(-50%); /* Center vertically */
    display: flex;
    flex-direction: column;
    gap: 18px;
    z-index: 9999;
}

.club-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-decoration: none;
}

.club-item img {
    width: 70px;
    height: 70px;
    border-radius: 50%;  /* round picture */
    object-fit: cover;
    border: 3px solid #3b82f6; /* blue ring */
    box-shadow: 0 4px 10px rgba(0,0,0,0.15);
    transition: 0.2s;
}

.club-item img:hover {
    transform: scale(1.05);
    border-color: #2563eb;
}

.club-item span {
    margin-top: 6px;
    font-size: 13px;
    font-weight: 600;
    color: #2563eb;
    text-align: center;
    width: 80px;
}
</style>
    <?php if ($message): ?>
        <div class="message <?php echo $messageType; ?>"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>

    <?php if ($profession === 'Staff'): ?>
    <div class="section">
        <h2>Create New Event</h2>
        <form method="POST" enctype="multipart/form-data">
            <div class="form-grid">
                <div>
                    <label>Event Name</label>
                    <input type="text" name="event_name" required placeholder="Workshop, Party...">
                </div>
                <div>
                    <label>Picture</label>
                    <input type="file" name="picture" accept="image/*">
                </div>
                <div>
                    <label>Date & Time</label>
                    <input type="datetime-local" name="date_time" required>
                </div>
                <div>
                    <label>Place</label>
                    <input type="text" name="place" required placeholder="Room 301, Garden...">
                </div>
                <div>
                    <label>Available Places</label>
                    <input type="number" name="available_places" value="50" min="1" required>
                </div>
                <div>
                    <label>Description (Optional)</label>
                    <textarea name="description" placeholder="What is this event about?"></textarea>
                </div>
            </div>
            <button type="submit" name="create_event" class="btn" style="margin-top:1rem;">Create Event</button>
        </form>
    </div>
    <div class="section">
    <h2>Create Story</h2>
    <form method="POST" enctype="multipart/form-data">
        <label>Upload Story Image</label>
        <input type="file" name="story_image" required accept="image/*">

        <label>Caption (optional)</label>
        <input type="text" name="caption" placeholder="What's happening?">

        <button type="submit" name="create_story" class="btn" style="margin-top:1rem;">
            Post Story
        </button>
    </form>
</div>

    <?php endif; ?>
    <div class="story-bar">
    <?php foreach ($stories as $s): ?>
        <div class="story-bubble" onclick="openStory('<?= $s['image'] ?>','<?= htmlspecialchars($s['caption']) ?>','<?= htmlspecialchars($s['name']) ?>')">
            <img src="<?= $s['image'] ?>" alt="">
            <span><?= htmlspecialchars($s['name']) ?></span>
        </div>
    <?php endforeach; ?>
</div>

<?php if ($profession === 'Student' || $profession === 'Teacher'): ?>
<a href="recommended.php" class="floating-ai-btn">
    🔮 Recommended Events
</a>
<?php endif; ?>

<style>
.floating-ai-btn {
    position: fixed;
    bottom: 25px;
    right: 25px;
    background: #3b82f6; /* same blue as your site */
    color: white;
    padding: 14px 20px;
    font-size: 1rem;
    font-weight: 600;
    border-radius: 50px;
    text-decoration: none;
    box-shadow: 0 6px 18px rgba(0,0,0,0.15);
    transition: 0.25s;
    z-index: 9999; /* always on top */
}

.floating-ai-btn:hover {
    background: #2563eb;
    transform: translateY(-3px);
}
</style>


    <h2>Upcoming Events</h2>
    <div class="events">
        <?php foreach ($events as $e):
            $full = $e['available_places'] <= 0;
            $reserved = in_array($e['id'], $my_reservations);
            $json = htmlspecialchars(json_encode($e), ENT_QUOTES);
        ?>
        <div class="card <?php echo $full?'full':''; ?>" onclick="showDetails(<?php echo $json; ?>)">
            <div class="card-img">
                <?php if ($e['picture']): ?>
                    <img src="<?php echo $e['picture']; ?>" alt="Event">
                <?php else: ?>
                    <div style="height:100%;background:#e5e7eb;display:grid;place-items:center;color:#999;font-size:0.9rem;">No Image</div>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <div class="card-title"><?php echo htmlspecialchars($e['name']); ?></div>
                <div class="card-meta">
                    <?php echo date('M j, Y \a\t g:i A', strtotime($e['date_time'])); ?><br>
                    <?php echo htmlspecialchars($e['place']); ?>
                </div>
                <div class="spots <?php echo $full?'full':'available'; ?>">
                    <?php echo $e['available_places']; ?> spot<?php echo $e['available_places']==1?'':'s'; ?> left
                </div>

                <?php if (!$full && in_array($profession, ['Student','Teacher'])): ?>
                <div class="card-actions">
                    <form method="POST" style="flex:1;">
                        <input type="hidden" name="event_id" value="<?php echo $e['id']; ?>">
                        <button type="submit" name="<?php echo $reserved ? 'unreserve_event' : 'reserve_event'; ?>" class="btn-small <?php echo $reserved ? 'btn-unreserve' : 'btn-reserve'; ?>" <?php echo $reserved ? '' : ''; ?>>
                            <?php echo $reserved ? 'Unreserve ✗' : 'Reserve Spot'; ?>
                        </button>
                    </form>
                    <button type="button" class="btn-small btn-details" onclick="event.stopPropagation(); showDetails(<?php echo $json; ?>)">
                        Details
                    </button>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
        <?php if (empty($events)): ?>
            <p style="text-align:center; color:var(--gray);">No events yet. <?php if ($profession === 'Staff'): ?>Create one above!<?php endif; ?></p>
        <?php endif; ?>
    </div>
</div>

<!-- Modal -->
<div id="modal" class="modal">
    <div class="modal-content">
        <button class="modal-close" onclick="document.getElementById('modal').classList.remove('show')">&times;</button>
        <div class="modal-header">
            <div class="modal-title" id="modal-title"></div>
        </div>
        <div class="modal-body" id="modal-body"></div>
    </div>
</div>
<div id="storyModal" class="story-modal">
    <div class="story-content">
        <img id="storyImage" src="" alt="">
        <p id="storyCaption"></p>
        <button onclick="closeStory()">×</button>
    </div>
</div>

<style>
.story-modal {
    position:fixed;
    top:0;left:0;
    width:100%;height:100%;
    background:rgba(0,0,0,0.85);
    display:none;
    justify-content:center;
    align-items:center;
    z-index:9999;
    animation: fadeIn 0.2s ease-out;
}

@keyframes fadeIn {
    from { opacity:0; }
    to { opacity:1; }
}

.story-content {
    position:relative;
    width:350px;           /* FIXED size */
    max-width:90%;
    background:#000;
    border-radius:20px;
    padding:15px;
    text-align:center;
}

.story-content img {
    width:100%;
    height:420px;         /* FIXED height */
    object-fit:cover;     /* Crop instead of stretching */
    border-radius:15px;
}

.story-content p {
    color:white;
    margin-top:12px;
    font-size:20px;       /* Bigger caption */
    font-weight:600;
}

.story-content button {
    position:absolute;
    top:10px;
    right:10px;
    background:rgba(0,0,0,0.6);
    color:white;
    border:none;
    font-size:22px;
    width:35px;
    height:35px;
    border-radius:50%;
    cursor:pointer;
}
</style>
<script>
let storyTimer;

function openStory(img, caption) {
    document.getElementById("storyImage").src = img;
    document.getElementById("storyCaption").innerText = caption;
    document.getElementById("storyModal").style.display = "flex";

    // Reset any previous timer
    clearTimeout(storyTimer);

    // Auto close after 5 seconds
    storyTimer = setTimeout(closeStory, 5000);
}

function closeStory() {
    document.getElementById("storyModal").style.display = "none";
    clearTimeout(storyTimer);
}
</script>

<script>
function openStory(img, caption, name) {
    document.getElementById("storyImage").src = img;
    document.getElementById("storyCaption").innerText = caption;
    document.getElementById("storyModal").style.display = "flex";
}
function closeStory() {
    document.getElementById("storyModal").style.display = "none";
}
</script>

<script>
function showDetails(e) {
    document.getElementById('modal-title').textContent = e.name;
    let html = '';
    if (e.picture) html += `<img src="${e.picture}" class="modal-img" alt="Event">`;
    html += `
        <p><strong>Date & Time:</strong> ${new Date(e.date_time).toLocaleString()}</p>
        <p><strong>Location:</strong> ${e.place}</p>
        <p><strong>Spots Left:</strong> ${e.available_places}</p>
        <p><strong>Created by:</strong> ${e.creator}</p>
    `;
    if (e.description) html += `<p><strong>About:</strong><br>${e.description.replace(/\n/g, '<br>')}</p>`;
    document.getElementById('modal-body').innerHTML = html;
    document.getElementById('modal').classList.add('show');
}
</script>

</body>
</html>